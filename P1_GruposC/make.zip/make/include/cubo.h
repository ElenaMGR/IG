#ifndef _CUBO_H
#define _CUBO_H

#include "obj3D.h"
#include <GL/glut.h>
#include <GL/gl.h>
using namespace std;

class Cubo : public Obj3D {

private:


public:
   Cubo();

};
#endif
