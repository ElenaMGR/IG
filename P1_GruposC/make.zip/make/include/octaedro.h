#ifndef _OCTAEDRO_H
#define _OCTAEDRO_H

#include "obj3D.h"
#include <GL/glut.h>
#include <GL/gl.h>
#include <math.h>

class Octaedro : public Obj3D {

private:


public:
   Octaedro();
};
#endif
