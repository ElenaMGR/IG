#ifndef _TETRAEDRO_H
#define _TETRAEDROD_H

#include "obj3D.h"
#include <GL/glut.h>
#include <GL/gl.h>

class Tetraedro : public Obj3D {

private:


public:
   Tetraedro();
};
#endif
